We appreciate any and all third-party contributions to help improve our SDKs
and UI Tools. When submitting any changes, please feel free to include your
name and company (if applicable) here for posterity.


Contributor offers to license certain software (a "Contribution" or multiple
“Contributions”) to Kloudless, and Kloudless agrees to accept said
Contributions, under the terms of the MIT open source license. 

Contributor understands and agrees that Kloudless shall have the irrevocable
and perpetual right to make and distribute copies of any Contribution, as well
as to create and distribute collective works and derivative works of any
Contribution, under the MIT License.

# Contributors

* Leo Zhang [@ilikebits](https://github.com/ilikebits)
* Timothy Liu [@pseudonumos](https://github.com/pseudonumos)
* Vinod Chandru [@vinodc](https://github.com/vinodc)
* Chris Kuehl [@chriskuehl](https://github.com/chriskuehl)
* Edward Look [@edwlook](https://github.com/edwlook)
* Steven Cheng [@chengsteven](https://github.com/chengsteven)
* Alice Cai [@ahcai](https://github.com/ahcai)
* Joeson Chiang [@joesonchiang](https://github.com/joesonchiang)
* Jackson Broussard [@jbrsrd](https://github.com/jbrsrd)
* Katie Low [@ktmellow](https://github.com/ktmellow)
* Artem Pisarev [@artemas](https://github.com/artemas)
